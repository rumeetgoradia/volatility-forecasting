# Regime-Aware Mixture-of-Experts for Volatility Forecasting

## Test Set Results Summary

### Overall Performance

| Model | RMSE | MAE | R² | QLIKE |
|-------|------|-----|----|----|
| lstm | 0.002082 | 0.001099 | 0.4621 | 0.0811 |
| tcn | 0.002115 | 0.001215 | 0.4448 | 0.0977 |
| ensemble | 0.002122 | 0.001170 | 0.4415 | 0.0990 |
| timesfm_fintext | 0.002672 | 0.001451 | 0.1142 | 0.1763 |
| chronos_fintext | 0.002689 | 0.001419 | 0.1027 | 0.1804 |
| har_rv | 0.002995 | 0.001576 | -0.1132 | 0.1695 |

**Best Model**: lstm (RMSE: 0.002082)

### Best Model Per Regime

| Regime | Best Model | RMSE | Second Best | RMSE |
|--------|------------|------|-------------|------|
| Low Volatility | lstm | 0.001056 | tcn | 0.001126 |
| Medium Volatility | ensemble | 0.001347 | lstm | 0.001401 |
| High Volatility | lstm | 0.003894 | ensemble | 0.003933 |

### Performance Matrix (RMSE)

| model           |    Low Vol |   Medium Vol |   High Vol |
|:----------------|-----------:|-------------:|-----------:|
| ensemble        | 0.00122774 |   0.00134714 | 0.00393299 |
| har_rv          | 0.00174396 |   0.00196145 | 0.0073072  |
| lstm            | 0.00105568 |   0.0014006  | 0.00389448 |
| tcn             | 0.00112595 |   0.00148157 | 0.00395804 |
| chronos_fintext | 0.00125934 |   0.00183725 | 0.00598477 |
| timesfm_fintext | 0.001318   |   0.00182145 | 0.00586249 |

### Statistical Significance

Diebold-Mariano tests: 14/15 pairwise comparisons show significant differences (p < 0.05)


**Ensemble vs Other Models:**

- vs har_rv: significantly different (p=0.0000), ensemble is better

- vs lstm: significantly different (p=0.0175), lstm is better

- vs tcn: not significantly different (p=0.4397), tcn is better

- vs chronos_fintext: significantly different (p=0.0000), ensemble is better

- vs timesfm_fintext: significantly different (p=0.0000), ensemble is better


## Key Findings

1. **LSTM achieves best performance** with RMSE of 0.002082

2. **Regime-aware ensemble** achieves competitive performance (RMSE: 0.002122, 1.9% gap)

3. **Ensemble significantly outperforms** HAR-RV, foundation models, and TCN

4. **LSTM dominates across all regimes** (wins in 2/3 regimes)

5. **Ensemble consistently ranks second** in 1/3 regimes


## Regime-Specific Insights

- **Low Vol**: lstm performs best (RMSE: 0.001056)

- **Medium Vol**: ensemble performs best (RMSE: 0.001347)

- **High Vol**: lstm performs best (RMSE: 0.003894)


## Configuration

- **Instruments**: 7

- **Regimes**: 3 (HMM-based)

- **Regime features**: RV_H1, RV_H6, volume_log, RV_30m, RV_120m

- **Test period**: 2022-01-01 to 2025-04-30
