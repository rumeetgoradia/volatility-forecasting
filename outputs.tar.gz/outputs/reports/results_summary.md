# Regime-Aware Mixture-of-Experts for Volatility Forecasting

## Test Set Results Summary

### Overall Performance

| Model | RMSE | MAE | R� | QLIKE |
|-------|------|-----|----|----|
| ensemble | 0.001637 | 0.000777 | 0.6675 | 0.0522 |
| timesfm_fintext_finetune_full | 0.001840 | 0.000943 | 0.5798 | 0.0824 |
| har_rv | 0.001915 | 0.000985 | 0.5452 | 0.0804 |
| lstm | 0.001961 | 0.000959 | 0.5230 | 1.9214 |
| timesfm_fintext_finetune_linear_probe | 0.001967 | 0.000998 | 0.5202 | 0.0952 |
| tcn | 0.001985 | 0.000969 | 0.5110 | 1.9571 |

**Best Model**: ensemble (RMSE: 0.001637)

### Best Model Per Regime

| Regime | Best Model | RMSE | Second Best | RMSE |
|--------|------------|------|-------------|------|
| Low Volatility | ensemble | 0.001205 | har_rv | 0.001222 |
| Medium Volatility | ensemble | 0.001999 | timesfm_fintext_finetune_full | 0.002173 |
| High Volatility | ensemble | 0.002554 | timesfm_fintext_finetune_full | 0.003075 |

### Performance Matrix (RMSE)

| model                                 |    Low Vol |   Medium Vol |   High Vol |
|:--------------------------------------|-----------:|-------------:|-----------:|
| ensemble                              | 0.00120507 |   0.00199917 | 0.00255394 |
| har_rv                                | 0.00122228 |   0.00220416 | 0.00355365 |
| lstm                                  | 0.0012873  |   0.00239202 | 0.00332699 |
| tcn                                   | 0.00129729 |   0.00228953 | 0.00354208 |
| timesfm_fintext_finetune_full         | 0.00130722 |   0.00217254 | 0.00307502 |
| timesfm_fintext_finetune_linear_probe | 0.00133195 |   0.00230858 | 0.00342691 |

### Statistical Significance

Diebold-Mariano tests: 8/15 pairwise comparisons show significant differences (p < 0.05)


**Ensemble vs Other Models:**

- vs har_rv: significantly different (p=0.0000), ensemble is better

- vs lstm: significantly different (p=0.0000), ensemble is better

- vs tcn: significantly different (p=0.0000), ensemble is better

- vs timesfm_fintext_finetune_full: significantly different (p=0.0000), ensemble is better

- vs timesfm_fintext_finetune_linear_probe: significantly different (p=0.0000), ensemble is better


## Key Findings

1. **ENSEMBLE achieves best performance** with RMSE of 0.001637

2. **Regime-aware ensemble** achieves competitive performance (RMSE: 0.001637, 0.0% gap)

3. **Ensemble significantly outperforms** HAR-RV, foundation models, and TCN

4. **LSTM dominates across all regimes** (wins in 0/3 regimes)


## Regime-Specific Insights

- **Low Vol**: ensemble performs best (RMSE: 0.001205)

- **Medium Vol**: ensemble performs best (RMSE: 0.001999)

- **High Vol**: ensemble performs best (RMSE: 0.002554)


## Configuration

- **Instruments**: 7

- **Regimes**: 3 (HMM-based)

- **Regime features**: RV_H1, RV_H6, volume_log, RV_30m, RV_120m

- **Test period**: 2022-01-01 to 2025-04-30
